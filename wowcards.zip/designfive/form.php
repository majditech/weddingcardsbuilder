﻿<!DOCTYPE html>
<html class="no-js" lang="en">
<head>

    <!--- basic page needs
    ================================================== -->
    <meta charset="utf-8">
    <title>Imminent - Slides</title>
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- mobile specific metas
    ================================================== -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSS
    ================================================== -->
    <link rel="stylesheet" href="../css/base.css">
    <link rel="stylesheet" href="../css/vendor.css">
    <link rel="stylesheet" href="../css/main.css">

    <!-- script
    ================================================== -->
    <script src="../js/modernizr.js"></script>
    <script defer src="../js/fontawesome/all.min.js"></script>

    <!-- favicons
    ================================================== -->
    <link rel="manifest" href="../site.webmanifest">

</head>

<body id="top">

<!-- preloader
    ================================================== -->
    <div id="preloader">
        <div id="loader" class="dots-fade">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>

    <!-- site header
    ================================================== -->
    <header class="s-header">

        <div class="header-logo">
            <a class="site-logo" href="index.html">
                <img src="../images/logo.png" alt="Homepage">
            </a>
        </div>

        <div class="header-email">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M0 12l11 3.1 7-8.1-8.156 5.672-4.312-1.202 15.362-7.68-3.974 14.57-3.75-3.339-2.17 2.925v-.769l-2-.56v7.383l4.473-6.031 4.527 4.031 6-22z"/></svg>
            <a href="mailto:#0">wedding@googlit.tech</a>
        </div>

    </header> <!-- end s-header -->


    <!-- intro
    ================================================== -->
    <section id="intro" class="s-intro s-intro--slides">

        <div class="intro-slider">
            <div class="intro-slider-img bg-opacity-40" style="background-image: url('../images/slides/slide-01.jpg');"></div>
            <div class="intro-slider-img" style="background-image: url('../images/slides/slide-02.jpg');"></div>
            <div class="intro-slider-img" style="background-image: url('../images/slides/slide-03.jpg');"></div>
        </div>

        <div class="grid-overlay">
            <div></div>
        </div> 

        <div class="row intro-content">

            <div class="column">

                <div class="intro-content__text">

                    <h3>
                    FILL THE WEDDING INFOMATION
                    </h3>
                    
                    <P>
                    <form action="index.php" method="post">
                    <input type="text" name="bride" placeholder="BDIDE NAME">
                    <input type="text" name="grome" placeholder="GROME NAME">
                    <input type="text" name="day" placeholder="saturday, Sunday, etc ...">
                    <input style="width:225px; height:50px; background-color:#dfdfdf; padding:20px;" type="date" name="date">                    
                    <input style="width:225px; height:50px; background-color:#dfdfdf; padding:20px;" type="time" name="time">
                    <input type="text" name="location" placeholder="City, Address, etc ...">
                    <input type="submit" value="CREATE YOUR CARD">

                    
                    </form>
                                    </P>

                </div> <!-- end intro-content__text -->

				<!-- end intro-content__bottom -->

            </div> <!-- end column -->

        </div> <!--  end intro-content -->

        <div class="modal">
            <div class="modal__inner">

                <span class="modal__close"></span>

                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M0 3v18h24v-18h-24zm6.623 7.929l-4.623 5.712v-9.458l4.623 3.746zm-4.141-5.929h19.035l-9.517 7.713-9.518-7.713zm5.694 7.188l3.824 3.099 3.83-3.104 5.612 6.817h-18.779l5.513-6.812zm9.208-1.264l4.616-3.741v9.348l-4.616-5.607z"/></svg>
            </div> <!-- end modal inner -->
        </div> <!-- end modal -->

        <ul class="intro-social">
            <li><a href="#0"><i class="fab fa-facebook" aria-hidden="true"></i></a></li>
            <li><a href="#0"><i class="fab fa-twitter" aria-hidden="true"></i></a></li>
            <li><a href="#0"><i class="fab fa-instagram" aria-hidden="true"></i></a></li>
            <li><a href="#0"><i class="fab fa-dribbble" aria-hidden="true"></i></a></li>
            <li><a href="#0"><i class="fab fa-behance" aria-hidden="true"></i></a></li>
        </ul> <!-- end intro social -->

<!-- end intro scroll -->

    </section> <!-- end s-intro -->


    <!-- info
    ================================================== -->

    <!-- Java Script
    ================================================== -->
    <script src="../js/jquery-3.2.1.min.js"></script>
    <script src="../js/plugins.js"></script>
    <script src="../js/main.js"></script>

</body>