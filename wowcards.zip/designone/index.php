﻿<!DOCTYPE html>
<html>
  
<head>
    <title>
        How to take screenshot of
        a div using JavaScript?
    </title>
  
    <!-- Include from the CDN -->
    <script src=
"https://cdn.jsdelivr.net/npm/html2canvas@1.0.0-rc.5/dist/html2canvas.min.js">
    </script>
  
    <!-- Include locally otherwise -->
    <!-- <script src='html2canvas.js'></script> -->
  
    <style>
        #photo {
            border: 4px solid #b0894f;
            padding: 4px;
        }
    .style1 {
	text-align: center;
	font-size: x-large;
	color:#373737;
	font-family: Gulim;
}
    .style2 {
	text-align: center;
	font-size:  50px;
}
    .style3 {
	font-family: "Edwardian Script ITC";
}
    .style4 {
	text-align: center;
	font-family: Gulim;
}
    .style5 {
	text-align: center;
	font-family: Gulim;
	font-size: x-large;
	color:#373737
}
body{
	background-color:#dfdfdf;
	text-align:center;
}
    </style>
</head>
  
<body>
    <div style="background-image:url('Design_Wedding_Card_01.jpg'); margin:auto; width:700px; height:480px;" id="photo">
        
	<br><br>
    <div class="style1">WEDDING<br>
		INVITATION</div>
		<br><br><br><br><br><div class="style2"><span class="style3"><?php $bride = $_POST['bride']; echo $bride; ?> &</span>
		<span class="style3"><?php $grome = $_POST['grome']; echo $grome; ?></span></div>
		<br><br><div class="style4">We would like to invite you to attend our<br>
		wedding sermon, <?php $day = $_POST['day']; echo $day; ?> <?php $date = $_POST['date']; echo $date; ?><br>
		at <?php $time = $_POST['time']; echo $time; ?></div>
		<br><br><br><br><br><div class="style5"><?php $location = $_POST['location']; echo $location; ?></div>    
    </div>
    <h1><button onclick="takeshot()">
            save your card as image
        </button></h1>
<h1>RIGHT CLICK &gt;&gt; SAVE IMAGE AS:&nbsp;</h1>
    <div id="output"></div>
  
    <script type="text/javascript">
  
        // Define the function 
        // to screenshot the div
        function takeshot() {
            let div =
                document.getElementById('photo');
  
            // Use the html2canvas
            // function to take a screenshot
            // and append it
            // to the output div
            html2canvas(div).then(
                function (canvas) {
                    document
                    .getElementById('output')
                    .appendChild(canvas);
                })
        }
    </script>
</body>
  
</html>