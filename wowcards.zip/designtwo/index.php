﻿<!DOCTYPE html>
<html>
  
<head>
    <title>
        How to take screenshot of
        a div using JavaScript?
    </title>
  
    <!-- Include from the CDN -->
    <script src=
"https://cdn.jsdelivr.net/npm/html2canvas@1.0.0-rc.5/dist/html2canvas.min.js">
    </script>
  
    <!-- Include locally otherwise -->
    <!-- <script src='html2canvas.js'></script> -->
  
    <style>
        #photo {
            border: 4px solid #b0894f;
            padding: 4px;
        }
    .style1 {
	text-align: center;
	font-size: large;
	color:#373737;
	font-family: Gulim;
}
    body{
	background-color:#dfdfdf;
	text-align:center;
}
    .style6 {
	font-size: x-large;
	margin-left: 160px;
}
    .style7 {
	font-size: 35pt;
	font-family: "Edwardian Script ITC";
	color:#9e9371;
}
    .style8 {
	font-family: Gulim;
}
.style9 {
	margin-left: 160px;
	color:#4f4f4f;
}
    </style>
</head>
  
<body>
    <div style="background-image:url('Design_Wedding_Card_01.jpg'); margin:auto; width:700px; height:480px;" id="photo">
        
	<br><br>
    <div class="style1">
		<p class="style6">Together with their families&nbsp; </p>
	</div>
 
		<div class="style7">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php $bride = $_POST['bride']; echo $bride; ?> &&nbsp; <?php $grome = $_POST['grome']; echo $grome; ?></div>
			<div class="style8">
				<p class="style9">Request the honor of your presence at their 
				marrige</p>
				<div>
					<p class="style9"><?php $day = $_POST['day']; echo $day; ?> at <?php $time = $_POST['time']; echo $time; ?> | <?php $location = $_POST['location']; echo $location; ?></p>
				</div>
				<div lass="style8"><p class="style9">WAITING FOR YOU</p></div>
		</div>  
    </div>
    <h1><button onclick="takeshot()">
            save your card as image
        </button></h1>
<h1>RIGHT CLICK &gt;&gt; SAVE IMAGE AS:&nbsp;</h1>
    <div id="output"></div>
  
    <script type="text/javascript">
  
        // Define the function 
        // to screenshot the div
        function takeshot() {
            let div =
                document.getElementById('photo');
  
            // Use the html2canvas
            // function to take a screenshot
            // and append it
            // to the output div
            html2canvas(div).then(
                function (canvas) {
                    document
                    .getElementById('output')
                    .appendChild(canvas);
                })
        }
    </script>
</body>
  
</html>